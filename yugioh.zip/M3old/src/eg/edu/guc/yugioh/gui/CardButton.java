package eg.edu.guc.yugioh.gui;

import javax.swing.JButton;

public class CardButton extends JButton {
	String name;
public CardButton(String name){
this.name=name;}
}
