package eg.edu.guc.yugioh.cards;

public enum Location {
	DECK, HAND, FIELD , GRAVEYARD ;
}
